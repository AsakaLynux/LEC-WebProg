<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class ContentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // DB::table('content')->insert([
        //     [
        //         'title' => 'heading'
        //         'content' => ''
        //     ],
        // ]);
    }
}
