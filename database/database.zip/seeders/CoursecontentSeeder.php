<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class CoursecontentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // DB::table('admin')->insert([
        //     [
        //         'course_id' => 1,
        //         'content_id' => 1
        //     ],
        //     [
        //         'username' => 'andirozi',
        //         'email' => 'andirozi@email.com',
        //         'password' => 'admin2'
        //     ],
        //     [
        //         'username' => 'irfansyah',
        //         'email' => 'irfansyaj@email.com',
        //         'password' => 'admin3'
        //     ]
        // ]);
    }
}
